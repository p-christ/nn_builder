# Neural-Network-Builder

Creates custom PyTorch neural networks in 1 line according to your specifications. 